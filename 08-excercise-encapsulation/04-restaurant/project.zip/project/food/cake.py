from project.food.dessert import Dessert
GRAMS = 250
CALORIES = 1000
PRICE = 5
class Cake(Dessert):
    pass