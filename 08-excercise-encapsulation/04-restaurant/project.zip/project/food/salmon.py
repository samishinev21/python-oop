from project.food.main_dish import MainDish
GRAMS = 22
class Salmon(MainDish):
    pass