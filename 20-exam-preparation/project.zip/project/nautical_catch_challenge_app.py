from typing import List

from project.fish.deep_sea_fish import DeapSeaFish
from project.fish.predatory_fish import PredatoryFish
from project.divers.free_diver import FreeDiver
from project.divers.scuba_diver import ScubaDiver
from project.fish.base_fish import BaseFish
from project.divers.base_diver import BaseDiver


class NauticalCatchChallengeApp:
    VALID_DIVERS = {"FreeDiver": FreeDiver, "ScubaDiver": ScubaDiver}
    VALID_FISHES = {"PredatoryFish": PredatoryFish, "DeepSeaFish": DeapSeaFish}

    def __init__(self):
        self.divers: List[BaseDiver] = []
        self.fish_list: List[BaseFish] = []

    def dive_into_competition(self, diver_type: str, diver_name: str):
        if diver_type in self.VALID_DIVERS.keys():
            diver = self.find_diver_by_name(diver_name)

            if diver:
                return f"{diver_name} is already a participant."
            else:
                diver = self.VALID_DIVERS[diver_type](diver_name)
                self.divers.append(diver)

                return f"{diver_name} is successfully registered for the competition as a {diver_type}."
        else:
            return f"{diver_type} is not allowed in our competition."

    def find_diver_by_name(self, name):
        for diver in self.divers:
            if diver.name == name:
                return diver

    def swim_into_competition(self, fish_type: str, fish_name: str, points: float):
        if fish_type in self.VALID_FISHES:
            pass
        else:
            return f"{fish_type} is forbidden for chasing in our competition."

    def find_fish_by_name(self, name):
        for fish in self.fish_list:
            if fish.name == name:
                return fish

    def chase_fish(self, diver_name: str, fish_name: str, is_lucky: bool):
        pass

    def health_recovery(self):
        pass

    def diver_catch_report(self, diver_name: str):
        pass

    def competition_statistics(self):
        pass
