from animals.animal import Bird
from food import Meat

class Owl(Bird):
    def make_sound(self):
        return "Hoot Hoot"
    
    def feed(self, food):
        if isinstance(food, Meat):
            self.weight += 0.25
            self.food_eaten += 1
        else:
            return f"Owl does not eat {type(food).__name__}"

class Hen(Bird):
    def make_sound(self):
        return "Cluck"
    
    def feed(self, _):
        self.weight += 0.35
        self.food_eaten += 1