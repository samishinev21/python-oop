from project.wizzard import Wizzard

class DarkWizzard(Wizzard):
    def __init__(self, username, level):
        super().__init__(username, level)
